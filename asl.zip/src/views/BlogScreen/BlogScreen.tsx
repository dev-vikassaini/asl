import React, { Component } from "react";
import { View, Text } from "react-native";

export default class BlogScreen extends Component<any, any> {
  render() {
    return (
      <View style={{ flex: 1 }}>
        <Text>Blog Screen</Text>
      </View>
    );
  }
}