import React from "react";

import {
  Text, Container, Card, CardItem, Body, Content, Header, Left, Right, Icon, Title, Button
} from "native-base";

export default class EditScreenOne extends React.Component<any, any> {
  static navigationOptions = ({ navigation }: { navigation: any }) => ({
    header: (
      <Header>
        <Left>
          <Button transparent onPress={() => navigation.goBack()}>
            <Icon name="arrow-back" />
          </Button>
        </Left>
        <Body>
          <Title>EditScreenOne</Title>
        </Body>
        <Right />
      </Header>
    )
  });
  render() {
    return (
      <Container>
        <Content padder>
          <Card>
            <CardItem>
              <Icon active name="paper-plane" />
              <Text>Edit Screen 1</Text>
              <Right>
                <Icon name="close" />
              </Right>
            </CardItem>
          </Card>
          <Button
            full
            rounded
            primary
            style={{ marginTop: 10 }}
            onPress={() => this.props.navigation.navigate("EditScreenTwo")}
          >
            <Text>Goto EditScreenTwo</Text>
          </Button>
        </Content>
      </Container>
    );
  }
}
